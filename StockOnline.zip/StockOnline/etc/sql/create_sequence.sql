Drop sequence subaccountseq;
Create sequence subaccountseq increment by 1 START WITH 3001 MAXVALUE 10000000 NOCYCLE CACHE 10000;

Drop sequence StockTransactionSeq;
Create sequence StockTransactionSeq increment by 1 START WITH 1 MAXVALUE 10000000 NOCYCLE CACHE 10000;
